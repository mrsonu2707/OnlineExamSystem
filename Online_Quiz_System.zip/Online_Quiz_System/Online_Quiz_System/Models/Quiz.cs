﻿using System;
using System.Collections.Generic;

namespace Online_Quiz_System.Models;

public partial class Quiz
{
    public int Id { get; set; }

    public int StudentId { get; set; }

    public DateTime? StartTime { get; set; }

    public DateTime? EndTime { get; set; }

    public virtual ICollection<Score> Scores { get; set; } = new List<Score>();

    public virtual Student? Student { get; set; }
}
