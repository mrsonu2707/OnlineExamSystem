﻿using System.ComponentModel.DataAnnotations.Schema;
using Online_Quiz_System.Models;

public partial class Score
{
    public int Id { get; set; }

    public int? QuizId { get; set; }

    [Column("Score")]  // ✅ Maps to SQL column [Score]
    public int Value { get; set; }   // ✅ Safe name

    public virtual Quiz? Quiz { get; set; }
}

