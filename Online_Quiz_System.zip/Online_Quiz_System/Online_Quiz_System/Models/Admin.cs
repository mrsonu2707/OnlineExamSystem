﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Online_Quiz_System.Models;

public partial class Admin
{
    public int Id { get; set; }
    [Required]
    [DisplayName("User Name")]
    public string Username { get; set; } = null!;
    [DisplayName("Password")]
    [DataType(DataType.Password)]
    public string PasswordHash { get; set; } = null!;
}
