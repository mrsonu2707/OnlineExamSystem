﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Online_Quiz_System.Models;

public partial class Newstudent
{
    public int Id { get; set; }

    [Required]
    [DisplayName("First Name")]
    public string? Name { get; set; }
    [Required]
    [DisplayName("Last Name")]
    public string? LastName { get; set; }
    [Required]

    [EmailAddress]
    public string? Email { get; set; }
    [Required]
    [DisplayName("Number")]
    public long? ContactNumber { get; set; }
    [Required]
    [DataType(DataType.Password)]
    public string? Password { get; set; }
}
