﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Online_Quiz_System.Models;

public partial class Student
{
    public int Id { get; set; }

    [DisplayName("First Name")]
    public string Name { get; set; } = null!;

    [DisplayName("Last Name")]
    public string Last_Name { get; set; } = null!;

    [EmailAddress]
    public string Email { get; set; } = null!;

    [DisplayName("Contact Number")]
    [Phone]
    public string Contact_Number { get; set; } = null!;

    [DisplayName("Password")]
    [DataType(DataType.Password)]
    public string Password { get; set; } = null!;

    public string Stream { get; set; } = null!;

    public virtual ICollection<Quiz> Quizzes { get; set; } = new List<Quiz>();
}
