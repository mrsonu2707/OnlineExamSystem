﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace Online_Quiz_System.Models;

public partial class NewdbsContext : DbContext
{
    public NewdbsContext()
    {
    }

    public NewdbsContext(DbContextOptions<NewdbsContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Admin> Admins { get; set; }

    public virtual DbSet<Newstudent> Newstudents { get; set; }

    public virtual DbSet<Question> Questions { get; set; }

    public virtual DbSet<Quiz> Quizzes { get; set; }

    public virtual DbSet<Score> Scores { get; set; }

    public virtual DbSet<Student> Students { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        if(!optionsBuilder.IsConfigured) 
        { }
    }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Admin>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Admin__3214EC0717B748F2");

            entity.ToTable("Admin");

            entity.Property(e => e.PasswordHash).HasMaxLength(500);
            entity.Property(e => e.Username).HasMaxLength(100);
        });

        modelBuilder.Entity<Newstudent>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__newstude__3214EC0736750D9F");

            entity.ToTable("newstudent");

            entity.Property(e => e.ContactNumber).HasColumnName("Contact_Number");
            entity.Property(e => e.Email)
                .HasMaxLength(33)
                .IsUnicode(false);
            entity.Property(e => e.LastName)
                .HasMaxLength(33)
                .IsUnicode(false)
                .HasColumnName("Last_Name");
            entity.Property(e => e.Name)
                .HasMaxLength(33)
                .IsUnicode(false);
            entity.Property(e => e.Password)
                .HasMaxLength(100)
                .IsUnicode(false);
        });

        modelBuilder.Entity<Question>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Question__3214EC07A79BB56C");

            entity.Property(e => e.CorrectAnswer).HasMaxLength(1);
            entity.Property(e => e.OptionA).HasMaxLength(100);
            entity.Property(e => e.OptionB).HasMaxLength(100);
            entity.Property(e => e.OptionC).HasMaxLength(100);
            entity.Property(e => e.OptionD).HasMaxLength(100);
            entity.Property(e => e.QuestionText).HasMaxLength(255);
            entity.Property(e => e.Stream).HasMaxLength(50);
        });

        modelBuilder.Entity<Quiz>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Quizzes__3214EC07236504CB");

            entity.Property(e => e.EndTime).HasColumnType("datetime");
            entity.Property(e => e.StartTime).HasColumnType("datetime");

            entity.HasOne(d => d.Student).WithMany(p => p.Quizzes)
                .HasForeignKey(d => d.StudentId)
                .HasConstraintName("FK__Quizzes__Student__3B75D760");
        });

        modelBuilder.Entity<Score>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Scores__3214EC078C361016");

            entity.Property(e => e.Value).HasColumnName("Score");

            entity.HasOne(d => d.Quiz).WithMany(p => p.Scores)
                .HasForeignKey(d => d.QuizId)
                .HasConstraintName("FK__Scores__QuizId__3E52440B");
        });

        modelBuilder.Entity<Student>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Students__3214EC078F6811AC");

            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.Last_Name).HasMaxLength(100);
            entity.Property(e => e.Contact_Number).HasMaxLength(20);
            entity.Property(e => e.Email).HasMaxLength(100);
            entity.Property(e => e.Password).HasMaxLength(500);
            entity.Property(e => e.Stream).HasMaxLength(50);
        });


        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
