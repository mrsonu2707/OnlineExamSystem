﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Online_Quiz_System.Models;





namespace Online_Quiz_System.Controllers
{
    public class StudentController : Controller
    {
        private readonly NewdbsContext context;

        public StudentController(NewdbsContext context)
        {
            this.context = context;
        }

        [HttpGet]
        public IActionResult Login()
        {
            try
            {
                if (HttpContext.Session.GetString("Student") != null)
                {
                    return RedirectToAction("Student_Dashboard", "Student");
                }
                return View();
            }
            catch (Exception ex)
            {
                return Content("Error: " + ex.Message);
            }
        }

        [HttpPost]
        public IActionResult Login(Student db)
        {
            try
            {
                var data = context.Students
                    .Where(x => x.Email == db.Email && x.Password == db.Password)
                    .FirstOrDefault();

                if (data != null)
                {
                    HttpContext.Session.SetString("Student", data.Email);
                    HttpContext.Session.SetString("Role", "Student");
                    return RedirectToAction("Student_Dashboard", "Student");
                }

                ViewBag.Error = "Invalid email or password";
                return View();
            }
            catch (Exception ex)
            {
                return Content("Login Error: " + ex.Message);
            }
        }

        [HttpGet]
        public IActionResult Student_Dashboard()
        {
            try
            {
                if (HttpContext.Session.GetString("Role") != "Student")
                    return RedirectToAction("Login", "Student");

                List<string> streams = context.Questions
                    .Select(q => q.Stream)
                    .Distinct()
                    .ToList();

                ViewBag.Streams = new SelectList(streams);
                return View();
            }
            catch (Exception ex)
            {
                return Content("Dashboard Error: " + ex.Message);
            }
        }

        [HttpPost]
        public IActionResult StartExam(string stream)
        {
            try
            {
                if (HttpContext.Session.GetString("Role") != "Student")
                    return RedirectToAction("Login", "Student");

                var questions = context.Questions
                    .Where(q => q.Stream == stream)
                    .Select(q => new ExamQuestionViewModel
                    {
                        Id = q.Id,
                        QuestionText = q.QuestionText,
                        OptionA = q.OptionA,
                        OptionB = q.OptionB,
                        OptionC = q.OptionC,
                        OptionD = q.OptionD,
                    }).ToList();

                ViewBag.Stream = stream;
                return View("StartExam", questions);
            }
            catch (Exception ex)
            {
                return Content("Start Exam Error: " + ex.Message);
            }
        }

        [HttpPost]
        public IActionResult SubmitExam(List<ExamQuestionViewModel> questions, string stream)
        {
            try
            {
                if (questions == null || !questions.Any())
                    return Content("No questions submitted.");

                var Email = HttpContext.Session.GetString("Student");
                var Student = context.Students.FirstOrDefault(s => s.Email == Email);

                var quiz = new Quiz
                {
                    StudentId = Student.Id,
                    StartTime = DateTime.Now,
                    EndTime = null
                };

                context.Quizzes.Add(quiz);
                context.SaveChanges();

                int score = 0;
                foreach (var q in questions)
                {
                    var original = context.Questions.FirstOrDefault(e => e.Id == q.Id);
                    if (original != null && original.CorrectAnswer == q.SelectedOption)
                        score++;
                }

                quiz.EndTime = DateTime.Now;
                context.SaveChanges();

                var scoreEntry = new Score
                {
                    QuizId = quiz.Id,
                    Value = score
                };
                context.Scores.Add(scoreEntry);
                context.SaveChanges();

                ViewBag.Score = score;
                ViewBag.Total = questions.Count;
                return View("Result");
            }
            catch (Exception ex)
            {
                return Content("Submit Exam Error: " + ex.Message);
            }
        }

        [HttpPost]
        public IActionResult Logout()
        {
            try
            {
                HttpContext.Session.Clear(); // Clear everything
                return RedirectToAction("Index", "Home"); // Always redirect to home
            }
            catch (Exception ex)
            {
                return Content("Logout Error: " + ex.Message);
            }
        }


        public IActionResult Index()
        {
            try
            {
                return View();
            }
            catch (Exception ex)
            {
                return Content("Index Error: " + ex.Message);
            }
        }
    }
}
