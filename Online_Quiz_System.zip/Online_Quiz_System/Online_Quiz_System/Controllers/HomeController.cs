using System;
using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Online_Quiz_System.Models;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace Online_Quiz_System.Controllers
{
    public class HomeController : Controller
    {
        private readonly NewdbsContext context;

        public HomeController(NewdbsContext context)
        {
            this.context = context;
        }

        public IActionResult Index()
        {
            return View();
        }

       

        public IActionResult Register()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Register(Student db)
        {
            if (ModelState.IsValid==true) 
            {
                context.Students.Add(db);
                context.SaveChanges();

                return RedirectToAction("Index");

            }
          

            return View(); // Return form with validation errors if any
        }






        public IActionResult Dashboard()
        {
            var role = HttpContext.Session.GetString("Role");

            if (role == "Admin")
            {
                return RedirectToAction("Index", "Admin");
            }
            else if (role == "Student")
            {
                return RedirectToAction("Student_Dashboard", "Student");
            }

            // Default fallback: go to login
            return RedirectToAction("Login", "Student");
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
