﻿using Microsoft.AspNetCore.Mvc;
using Online_Quiz_System.Models;

namespace Online_Quiz_System.Controllers
{
    public class AdminController : Controller
    {
        private readonly NewdbsContext context;

        public AdminController(NewdbsContext context)
        {
            this.context = context;
        }
        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        // POST - Authenticate Admin
        [HttpPost]
        public IActionResult Login(Admin admin)
        {
            var data = context.Admins.Where(x => x.Username == admin.Username && x.PasswordHash == admin.PasswordHash).FirstOrDefault();
            if (data != null)
            {
                HttpContext.Session.SetString("Admin", data.Username);       // ✅ Optional: admin ka naam

                HttpContext.Session.SetString("Role", "Admin");             // ✅ Required for role-based content

                return RedirectToAction("Index", "Admin");



            }

            if (HttpContext.Session.GetString("Role") != "Admin")
            {
                return RedirectToAction("Index", "Home");
            }


            ViewBag.Error = "Login Faild as Admin";
            return View();
        }

        public IActionResult Logout()
        {

            HttpContext.Session.Remove("Admin");
            return RedirectToAction("Index" , "Home");

        }
        public IActionResult Index()
        {
            var data = context.Questions.ToList();
            return View(data);
        }

        public IActionResult Create(Question obj) 
        {
            if (ModelState.IsValid == true) { 
            context.Questions.Add(obj);
            context.SaveChanges();
                return RedirectToAction("Index");
            }
            return View();
        }

        public IActionResult Edit(int Id) 
        {
            var data = context.Questions.Where(x => x.Id == Id).FirstOrDefault();
            return View(data);
        }

        [HttpPost]
        public IActionResult Edit(Question obj)
        {
            context.Entry(obj).State = Microsoft.EntityFrameworkCore.EntityState.Modified;
            context.SaveChanges();
            return RedirectToAction("Index");
       
            
        }

        public IActionResult Delete(int ID)
        {
            var data = context.Questions.Where(x => x.Id == ID).FirstOrDefault();
            context.Entry(data).State = Microsoft.EntityFrameworkCore.EntityState.Deleted;
            context.SaveChanges();
            return RedirectToAction("Index");
        }

        public IActionResult Details(int ID) 
        {
            var data = context.Questions.Where(x => x.Id == ID).FirstOrDefault();
            if (data == null) 
            {
                return NotFound();
            }
            return View(data);
        }
    }
}
